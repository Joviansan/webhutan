import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

function HeroSection({ handleFeatureClick }) {
  return (
    <section className="relative h-screen flex items-center justify-center bamboo-pattern">
      <div className="absolute inset-0 bg-black/30"></div>
      <img  
        className="absolute inset-0 w-full h-full object-cover" 
        alt="Hutan bambu hijau yang rimbun di Sandan Tabanan"
       src="https://images.unsplash.com/photo-1423958355704-a2ea8a6d597d" />
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <motion.h1 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-5xl md:text-7xl font-bold text-white mb-6 text-shadow font-['Playfair_Display']"
        >
          Bambu Hutan
          <span className="block text-green-300">Sandan Tabanan</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="text-xl md:text-2xl text-white mb-8 text-shadow"
        >
          Rasakan ketenangan di tengah rimbunan bambu yang menjulang tinggi
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button 
            onClick={() => handleFeatureClick('Jelajahi Sekarang')}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Jelajahi Sekarang
          </Button>
          <Button 
            onClick={() => handleFeatureClick('Lihat Galeri')}
            variant="outline" 
            className="border-white text-white hover:bg-white hover:text-green-800 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300"
          >
            Lihat Galeri
          </Button>
        </motion.div>
      </div>
    </section>
  );
}

export default HeroSection;