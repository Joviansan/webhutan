import React from 'react';
import { motion } from 'framer-motion';
import { Mountain, TreePine, Waves, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';

function AboutSection({ handleFeatureClick }) {
  return (
    <section className="section-spacing bg-gradient-to-r from-green-50 to-green-100">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-green-800 mb-6 font-['Playfair_Display']">
              Keajaiban Alam Sandan
            </h2>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Hutan bambu Sandan Tabanan merupakan destinasi wisata alam yang menakjubkan, 
              terletak di kawasan pegunungan Bali yang sejuk dan asri. Dengan ribuan batang 
              bambu yang menjulang tinggi, tempat ini menawarkan pengalaman spiritual dan 
              ketenangan yang tak terlupakan.
            </p>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="flex items-center space-x-2">
                <TreePine className="h-5 w-5 text-green-600" />
                <span className="text-gray-700">Udara Segar</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mountain className="h-5 w-5 text-green-600" />
                <span className="text-gray-700">Pemandangan Indah</span>
              </div>
              <div className="flex items-center space-x-2">
                <Waves className="h-5 w-5 text-green-600" />
                <span className="text-gray-700">Suara Alam</span>
              </div>
              <div className="flex items-center space-x-2">
                <Sun className="h-5 w-5 text-green-600" />
                <span className="text-gray-700">Cuaca Sejuk</span>
              </div>
            </div>
            <Button 
              onClick={() => handleFeatureClick('Pelajari Lebih Lanjut')}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full"
            >
              Pelajari Lebih Lanjut
            </Button>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bamboo-sway"
          >
            <div className="bamboo-border p-4 bg-white">
              <img  
                className="w-full h-96 object-cover rounded-lg" 
                alt="Dua orang di hutan bambu Sandan, menyerahkan bibit bambu"
               src="https://horizons-cdn.hostinger.com/9cf14cad-5acc-4c40-9be8-baa11e5d37ab/822f6b358c6188cb92aa920b7ee6724c.png" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default AboutSection;