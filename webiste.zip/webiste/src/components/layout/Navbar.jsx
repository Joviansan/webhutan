import React from 'react';
import { motion } from 'framer-motion';
import { Leaf } from 'lucide-react';

function Navbar({ handleFeatureClick }) {
  return (
    <nav className="fixed top-0 w-full z-50 glass-effect">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center space-x-2"
          >
            <Leaf className="h-8 w-8 text-green-400" />
            <span className="text-xl font-bold text-white font-['Playfair_Display']">Bambu Sandan</span>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="hidden md:flex space-x-6"
          >
            {['Beranda', 'Tentang', 'Galeri', 'Aktivitas', 'Kontak'].map((item) => (
              <button
                key={item}
                onClick={() => handleFeatureClick(item)}
                className="text-white hover:text-green-300 transition-colors duration-300 font-medium"
              >
                {item}
              </button>
            ))}
          </motion.div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;