import React from 'react';
import { Leaf } from 'lucide-react';

function Footer() {
  return (
    <footer className="bg-green-950 py-8">
      <div className="container mx-auto px-4 text-center">
        <div className="flex justify-center items-center space-x-2 mb-4">
          <Leaf className="h-6 w-6 text-green-400" />
          <span className="text-xl font-bold text-white font-['Playfair_Display']">Bambu Sandan</span>
        </div>
        <p className="text-green-300 mb-4">
          Melestarikan keindahan alam untuk generasi mendatang
        </p>
        <p className="text-green-400 text-sm">
          © 2024 Bambu Hutan Sandan Tabanan. Semua hak dilindungi.
        </p>
      </div>
    </footer>
  );
}

export default Footer;