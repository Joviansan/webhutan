import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';

// Layout Components
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';

// Section Components
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import FeaturesSection from '@/components/sections/FeaturesSection';
import GallerySection from '@/components/sections/GallerySection';
import ContactSection from '@/components/sections/ContactSection';

function App() {
  const handleFeatureClick = (feature) => {
    toast({
      title: "🚧 Fitur Belum Tersedia",
      description: "Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 3000,
    });
  };

  return (
    <>
      <Helmet>
        <title>Bambu Hutan Sandan Tabanan - Wisata Alam Eksotis Bali</title>
        <meta name="description" content="Jelajahi keindahan hutan bambu Sandan Tabanan, destinasi wisata alam yang menakjubkan di Bali dengan pemandangan hijau yang mempesona dan udara segar pegunungan." />
        <meta property="og:title" content="Bambu Hutan Sandan Tabanan - Wisata Alam Eksotis Bali" />
        <meta property="og:description" content="Jelajahi keindahan hutan bambu Sandan Tabanan, destinasi wisata alam yang menakjubkan di Bali dengan pemandangan hijau yang mempesona dan udara segar pegunungan." />
      </Helmet>

      <div className="min-h-screen">
        <Navbar handleFeatureClick={handleFeatureClick} />
        <HeroSection handleFeatureClick={handleFeatureClick} />
        <AboutSection handleFeatureClick={handleFeatureClick} />
        <FeaturesSection handleFeatureClick={handleFeatureClick} />
        <GallerySection handleFeatureClick={handleFeatureClick} />
        <ContactSection handleFeatureClick={handleFeatureClick} />
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;