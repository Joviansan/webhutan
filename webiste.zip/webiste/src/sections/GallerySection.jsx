import React from 'react';
import { motion } from 'framer-motion';

function GallerySection({ handleFeatureClick }) {
  const bamboos = [
    { 
      title: "Bambu Hitam",
      description: "Dikenal karena warnanya yang eksotis dan elegan, bambu hitam sering digunakan untuk furnitur, alat musik, dan dekorasi. Batangnya kuat dan memiliki daya tahan yang tinggi.",
      alt: "Bambu Hitam, bambu eksotis dengan warna gelap", 
      image_description: "Batang-batang bambu hitam yang rimbun dan eksotis"
    },
    { 
      title: "Bambu Kuning",
      description: "Jenis bambu hias yang populer dengan batang berwarna kuning cerah bergaris hijau. Dipercaya membawa keberuntungan dan sering ditanam sebagai pagar hidup atau elemen taman.",
      alt: "Bambu Kuning, bambu hias dengan warna cerah", 
      image_description: " rumpun bambu kuning cerah dengan garis-garis hijau"
    },
    { 
      title: "Bambu Petung",
      description: "Salah satu jenis bambu terbesar dengan diameter batang yang bisa mencapai 20 cm. Sangat kuat dan ideal digunakan sebagai bahan utama konstruksi bangunan dan jembatan.",
      alt: "Bambu Petung, jenis bambu besar dan kuat", 
      image_description: "Batang bambu petung yang besar dan kokoh"
    },
    { 
      title: "Bambu Tali",
      description: "Memiliki serat yang lentur dan kuat, membuatnya menjadi bahan baku utama untuk kerajinan tangan seperti tali, anyaman, dan furnitur. Batangnya lebih ramping dan fleksibel.",
      alt: "Bambu Tali, bambu ramping untuk kerajinan", 
      image_description: "Bambu tali yang ramping dan fleksibel, siap untuk dianyam"
    },
    { 
      title: "Bambu Apus",
      description: "Bambu serbaguna yang paling umum dijumpai. Dinding batangnya tipis namun kuat, sering dimanfaatkan untuk rangka atap, dinding anyaman (gedek), dan berbagai perabotan rumah tangga.",
      alt: "Bambu Apus, bambu serbaguna untuk konstruksi", 
      image_description: "Sekelompok bambu apus yang tinggi dan lurus"
    },
    { 
      title: "Bambu Ampel",
      description: "Tumbuh dalam rumpun yang rapat dan tidak terlalu besar. Sering digunakan sebagai sayuran (rebungnya) dan bahan kerajinan ringan. Mudah dibudidayakan di pekarangan rumah.",
      alt: "Bambu Ampel, bambu umum dengan banyak kegunaan", 
      image_description: "Rumpun bambu ampel yang hijau dan lebat"
    },
  ];

  return (
    <section className="section-spacing bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-green-800 mb-4 font-['Playfair_Display']">
            Galeri Jenis Bambu
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Kenali berbagai jenis bambu yang tumbuh subur di Tabanan, Bali
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {bamboos.map((bamboo, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group bg-white rounded-lg shadow-lg overflow-hidden flex flex-col bamboo-border-subtle"
            >
              <div className="relative overflow-hidden">
                <img 
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500" 
                  alt={bamboo.alt} src="https://images.unsplash.com/photo-1639783105299-c41589e783bb" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
              </div>
              <div className="p-6 flex-grow flex flex-col">
                <h3 className="text-2xl font-bold text-green-800 font-['Playfair_Display'] mb-2">{bamboo.title}</h3>
                <p className="text-gray-700 leading-relaxed flex-grow">{bamboo.description}</p>
                <button 
                  onClick={() => handleFeatureClick('Pelajari Lebih Lanjut')}
                  className="mt-4 text-green-600 font-semibold hover:text-green-800 transition-colors self-start">
                  Pelajari Lebih Lanjut →
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default GallerySection;