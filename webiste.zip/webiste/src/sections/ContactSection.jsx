import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';

function ContactSection({ handleFeatureClick }) {
  return (
    <section className="section-spacing bg-green-900">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-['Playfair_Display']">
              Kunjungi Kami
            </h2>
            <p className="text-xl text-green-200 mb-8">
              Rencanakan perjalanan Anda ke hutan bambu Sandan Tabanan dan rasakan keajaiban alam Bali
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MapPin className="h-6 w-6 text-green-400" />
                <span className="text-white">Sandan, Tabanan, Bali, Indonesia</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-6 w-6 text-green-400" />
                <span className="text-white">+62 361 123 4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-6 w-6 text-green-400" />
                <span className="text-white">info@bambusandan.com</span>
              </div>
            </div>

            <div className="mt-8">
              <Button 
                onClick={() => handleFeatureClick('Hubungi Kami')}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-full text-lg font-semibold"
              >
                Hubungi Kami
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bamboo-sway"
          >
            <div className="bamboo-border p-4 bg-white">
              <img  
                className="w-full h-96 object-cover rounded-lg" 
                alt="Peta lokasi hutan bambu Sandan Tabanan"
               src="https://images.unsplash.com/photo-1597392264161-f37b120434f9" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default ContactSection;