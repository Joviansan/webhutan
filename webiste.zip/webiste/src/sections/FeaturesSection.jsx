import React from 'react';
import { motion } from 'framer-motion';
import { Camera, TreePine, Leaf } from 'lucide-react';

function FeaturesSection({ handleFeatureClick }) {
  const features = [
    {
      icon: Camera,
      title: "Fotografi Alam",
      description: "Abadikan momen indah di antara bambu yang menjulang tinggi dengan cahaya alami yang memukau"
    },
    {
      icon: TreePine,
      title: "Trekking Hutan",
      description: "Jelajahi jalur-jalur tersembunyi dan rasakan kedamaian di tengah rimbunan bambu"
    },
    {
      icon: Leaf,
      title: "Meditasi Alam",
      description: "Temukan ketenangan batin dengan suara gemericik air dan angin yang bertiup lembut"
    }
  ];

  return (
    <section className="section-spacing bg-green-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 font-['Playfair_Display']">
            Aktivitas Menarik
          </h2>
          <p className="text-xl text-green-200 max-w-2xl mx-auto">
            Nikmati berbagai aktivitas seru di tengah keindahan hutan bambu
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="glass-effect p-6 rounded-xl text-center hover:transform hover:scale-105 transition-all duration-300 cursor-pointer"
              onClick={() => handleFeatureClick(feature.title)}
            >
              <feature.icon className="h-12 w-12 text-green-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-green-200">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default FeaturesSection;